import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class ExecuteQuery {

    public static void runSQLFile(Connection conn, String fileName, CarRentalDBGUI gui) {
        try {
            // Read the entire SQL file into one big string
            String sql = new String(Files.readAllBytes(Paths.get(fileName))); 

            // Split the string into individual SQL statements using ";" as the separator
            String[] statements = sql.split(";"); 

            Statement stmt = conn.createStatement();

            int queryNumber = 1;
            for (String s : statements) {
                // Skip empty statements
                if (s.trim().isEmpty()) continue;
                
                try {
                    gui.appendOutput("Query " + queryNumber + ":");
                    gui.appendOutput("");

                    // Execute the SQL command
                    ResultSet rs = stmt.executeQuery(s.trim());

                    // Get metadata to display column names
                    ResultSetMetaData metaData = rs.getMetaData();
                    int columnCount = metaData.getColumnCount();

                    // Determine column widths based on column names
                    int[] columnWidths = new int[columnCount];
                    int totalWidth = 0;
                    for (int i = 1; i <= columnCount; i++) {
                        String columnName = metaData.getColumnName(i).toLowerCase();
                        
                        // Set custom widths for specific columns
                        if (columnName.contains("email")) {  
                            columnWidths[i-1] = 40;
                        } 
                        else if (columnName.contains("feedback")) {
                            columnWidths[i-1] = 40;
                        }
                        else if (columnName.contains("date")) {
                            columnWidths[i-1] = 30;
                        }
                        else {
                            columnWidths[i-1] = 20; 
                        }
                        totalWidth += columnWidths[i-1];
                    }

                    // Display column headers
                    StringBuilder header = new StringBuilder();
                    for (int i = 1; i <= columnCount; i++) {
                        header.append(String.format("%-" + columnWidths[i-1] + "s", metaData.getColumnName(i)));
                    }
                    gui.appendOutput(header.toString());
                    gui.appendOutput("-".repeat(totalWidth));

                    // Display results
                    while (rs.next()) {
                        StringBuilder row = new StringBuilder();
                        for (int i = 1; i <= columnCount; i++) {
                            String value = rs.getString(i);
                            if (value == null) value = "NULL";
                            row.append(String.format("%-" + columnWidths[i-1] + "s", value));
                        }
                        gui.appendOutput(row.toString());
                    }

                    gui.appendOutput("");

                    rs.close();
                    queryNumber++;
                    
                } 
                catch (SQLException e) {
                    gui.appendOutput("Error executing query:");
                    gui.appendOutput(e.getMessage());
                    gui.appendOutput("");
                }
            }
            stmt.close();
            gui.appendOutput("All queries executed successfully!");
        } 
        
        catch (IOException | SQLException e) {
            gui.appendOutput("Error reading file or connecting to database:");
            gui.appendOutput(e.getMessage());
            e.printStackTrace();
        }
    }
}