import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class Execute {

    public static void runSQLFile(Connection conn, String fileName) {
        try {
            // Read the entire SQL file into one big string
            String sql = new String(Files.readAllBytes(Paths.get(fileName))); 

            // Split the string into individual SQL statements using ";" as the separator
            String[] statements = sql.split(";"); 

            // Create a Statement object to execute SQL commands
            Statement stmt = conn.createStatement();

            for (String s : statements) {
                // Skip empty statements
                if (s.trim().isEmpty()) continue;
                try {
                     // Execute the SQL command
                    stmt.execute(s.trim());
                } 
                catch (SQLException e) {
                    System.out.println("Error executing: " + s);
                    System.out.println(e.getMessage());
                }
            }
            stmt.close();
        } 
        
        catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }
}

