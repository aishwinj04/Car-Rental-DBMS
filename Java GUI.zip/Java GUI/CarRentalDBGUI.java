import java.awt.*;
import java.sql.*;
import javax.swing.*;

public class CarRentalDBGUI extends JFrame {

    // GUI components
    private JTextArea queryOutputArea;
    private JButton btnCreate, btnDrop, btnPopulate, btnQuery, btnExit;
    private JLabel statusLabel;

    // Database connection
    private Connection conn;

    public CarRentalDBGUI(Connection connection) {
        this.conn = connection;

        setTitle("Car Rental DBMS");
        setSize(1200, 650);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        initComponents();
    }

    private void initComponents() {
        // Title
        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        JLabel titleLabel = new JLabel("Car Rental DBMS");
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 24));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        titlePanel.add(titleLabel);
        titlePanel.add(Box.createRigidArea(new Dimension(0, 5)));

        // Button Panel
        btnCreate = new JButton("Create");
        btnDrop = new JButton("Drop");
        btnPopulate = new JButton("Populate");
        btnQuery = new JButton("Query");
        btnExit = new JButton("Exit");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(btnDrop);
        buttonPanel.add(btnCreate);
        buttonPanel.add(btnPopulate);
        buttonPanel.add(btnQuery);
        buttonPanel.add(btnExit);

        // Query Output TextArea
        queryOutputArea = new JTextArea();
        queryOutputArea.setEditable(false);
        queryOutputArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        queryOutputArea.setLineWrap(false); 
        queryOutputArea.setWrapStyleWord(false);  
        JScrollPane textScroll = new JScrollPane(queryOutputArea);
        textScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED); 
        textScroll.setBorder(BorderFactory.createTitledBorder(""));

        // Status label to ensure correct connection 
        statusLabel = new JLabel("Status: Connected");

        JPanel mainPanel = new JPanel(new BorderLayout());
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
        topPanel.add(titlePanel);
        topPanel.add(buttonPanel);
        
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(textScroll, BorderLayout.CENTER);
        mainPanel.add(statusLabel, BorderLayout.SOUTH);

        setContentPane(mainPanel);

        // Button handlers
        btnDrop.addActionListener(e -> drop_tables());
        btnCreate.addActionListener(e -> create_tables());
        btnPopulate.addActionListener(e -> populate_tables());
        btnQuery.addActionListener(e -> queries());
        
        // Added Exit Button
        btnExit.addActionListener(e -> System.exit(0));
    }
    
    // Method to append text to the output area
    public void appendOutput(String text) {
        queryOutputArea.append(text + "\n");
        queryOutputArea.setCaretPosition(queryOutputArea.getDocument().getLength());
    }
    
    // Method to clear the output area
    public void clearOutput() {
        queryOutputArea.setText("");
    }
    
    // Method for each button
    private void drop_tables() {
        Execute.runSQLFile(conn, "drop_tables.sql");
        queryOutputArea.setText("Tables dropped successfully!");
    }
    private void create_tables() {
        Execute.runSQLFile(conn, "create_tables.sql");
        queryOutputArea.setText("Tables created successfully!");
    }
    private void populate_tables() {
        Execute.runSQLFile(conn, "populate_tables.sql");
        queryOutputArea.setText("Tables populated successfully!");
    }
    private void queries() {
        clearOutput();  // Clear previous output
        ExecuteQuery.runSQLFile(conn, "queries.sql", this);
    }

}