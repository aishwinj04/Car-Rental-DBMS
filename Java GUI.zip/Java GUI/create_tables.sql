CREATE TABLE Customer (
    CustomerID NUMBER PRIMARY KEY,
    FirstName VARCHAR2(50) NOT NULL,
    MiddleName VARCHAR2(50),
    LastName VARCHAR2(50) NOT NULL,
    PhoneNumber VARCHAR2(15) UNIQUE,
    Email VARCHAR2(100) UNIQUE,
    StreetNumber VARCHAR2(10) NOT NULL,
    StreetName VARCHAR2(100) NOT NULL,
    City VARCHAR2(50) NOT NULL,
    DriversLicense VARCHAR2(20) UNIQUE NOT NULL,
    CHECK (PhoneNumber IS NOT NULL OR Email IS NOT NULL)
);

CREATE TABLE Vehicle(
    VehicleID NUMBER PRIMARY KEY,
    FuelCapacity NUMBER(3) NOT NULL CHECK (FuelCapacity > 0),
    DailyRate NUMBER(6,2) NOT NULL CHECK (DailyRate > 0),
    VType VARCHAR2(8) NOT NULL CHECK (VType IN ('Economy', 'Luxury')),
    Plate VARCHAR2(10) UNIQUE NOT NULL,
    Model VARCHAR2(50) NOT NULL,
    VStatus VARCHAR2(12) DEFAULT 'Available' NOT NULL  CHECK (VStatus IN ('Available', 'Rented', 'Maintenance'))
);

-- Multivalued Attribute of Vehicle
CREATE TABLE VehicleColour(
    VehicleID NUMBER NOT NULL,
    Colour VARCHAR2(20) NOT NULL CHECK (Colour IN ('Red', 'Black', 'White', 'Blue', 'Silver', 'Grey','Green', 'Orange', 'Yellow', 'Purple', 'Pink', 'Brown')),
    PRIMARY KEY (VehicleID, Colour),
    FOREIGN KEY (VehicleID) REFERENCES Vehicle(VehicleID)

);

CREATE TABLE Review(
    ReviewID NUMBER PRIMARY KEY,
    Rating NUMBER(1) NOT NULL CHECK (Rating >= 1 AND Rating <= 5),
    ReviewDate DATE,
    Feedback VARCHAR2(200),
    WritingMethod VARCHAR2(10) DEFAULT 'Online',
    CustomerID NUMBER NOT NULL,
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID),
    VehicleID NUMBER NOT NULL,
    FOREIGN KEY (VehicleID) REFERENCES Vehicle(VehicleID)
);

CREATE TABLE Reservation(
    ReservationID NUMBER PRIMARY KEY,
    RStatus VARCHAR2(10) NOT NULL CHECK (RStatus IN ('Pending', 'Confirmed', 'Cancelled')),
    PPickupDate DATE NOT NULL,
    PReturnDate DATE NOT NULL,
    CustomerID NUMBER NOT NULL,
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID),
    VehicleID NUMBER NOT NULL,
    FOREIGN KEY (VehicleID) REFERENCES Vehicle(VehicleID),
    CHECK (PPickupDate < PReturnDate)
);

-- Weak Entity 
CREATE TABLE Maintenance(
    ServiceDate DATE NOT NULL,
    MStatus VARCHAR2(25) NOT NULL CHECK (MStatus IN ('Needs_Maintenance', 'Under_Maintenance', 'Maintenance_Completed')),
    VehicleID NUMBER NOT NULL,
    PRIMARY KEY (VehicleID, ServiceDate),
    FOREIGN KEY (VehicleID) REFERENCES Vehicle(VehicleID)
);

-- Subclass of Maintenance
CREATE TABLE Repairs(
    RepairType VARCHAR(20) NOT NULL,
    VehicleID NUMBER NOT NULL,
    ServiceDate DATE NOT NULL,
    PRIMARY KEY(VehicleID, ServiceDate, RepairType), -- repairtype in primary key so we can have multiple repairs on the same vehicle on same date
    FOREIGN KEY(VehicleID, ServiceDate) REFERENCES Maintenance(VehicleID, ServiceDate) 
);

-- Multivalued Attribute of Repair
CREATE TABLE PartsRepaired(
    VehicleID NUMBER NOT NULL,
    ServiceDate DATE NOT NULL, 
    Part VARCHAR(30) NOT NULL,
    RepairType VARCHAR(20) NOT NULL,
    PRIMARY KEY(VehicleID, ServiceDate, RepairType, Part), -- part is part of the primary key for mulitple parts repaired
    FOREIGN KEY(VehicleID, ServiceDate, RepairType) REFERENCES Repairs(VehicleID, ServiceDate, RepairType)
);

-- Subclass of Maintenance
CREATE TABLE Cleaning(
    CleaningArea VARCHAR2(20) NOT NULL CHECK (CleaningArea IN ('Interior', 'Exterior')), 
    DetailLevel VARCHAR(20) NOT NULL CHECK (DetailLevel IN ('Basic', 'Deep', 'Premium')),
    VehicleID NUMBER NOT NULL,
    ServiceDate DATE NOT NULL,
    PRIMARY KEY(VehicleID, ServiceDate, CleaningArea), -- cleaning area part of the primary key so a vehicle can have exterior and interior cleaning on same date
    FOREIGN KEY(VehicleID, ServiceDate)REFERENCES Maintenance(VehicleID, ServiceDate)
);

CREATE TABLE Rental(
    RentalID NUMBER PRIMARY KEY,
    PickupDate DATE NOT NULL,
    ReturnDate DATE NOT NULL,
    RentalCost NUMBER(7,2) NOT NULL CHECK (RentalCost > 0),
    FuelCharge NUMBER(6,2),
    FuelLevel NUMBER(4) NOT NULL,
    ReservationID NUMBER NOT NULL UNIQUE,
    FOREIGN KEY (ReservationID) REFERENCES Reservation(ReservationID),
    CHECK (PickupDate < ReturnDate)
);

CREATE TABLE Payment(
    PaymentID NUMBER PRIMARY KEY,
    PaymentDate DATE NOT NULL,
    PaymentMethod VARCHAR2(8) NOT NULL CHECK (PaymentMethod IN ('Credit', 'Debit', 'Cash', 'Mobile', 'Online')),
    TotalAmount NUMBER(8,2) NOT NULL CHECK (TotalAmount > 0),
    RentalID NUMBER NOT NULL UNIQUE,
    FOREIGN KEY (RentalID) REFERENCES Rental(RentalID)
);


-- V1: Shows each customer names, vehicle they reserved and pickup/return dates - uses join.  
Create VIEW customer_reservations(FirstName, LastName, VehicleID, PickupDate, ReturnDate) AS (
SELECT FirstName, LastName, VehicleID, PPickupDate, PReturnDate 
FROM Customer, Reservation
WHERE Customer.CustomerID = Reservation.CustomerID
);

-- V2: Lists all customers who have provided a phone number
CREATE VIEW customers_with_phone AS (
SELECT * 
FROM Customer 
WHERE PhoneNumber IS NOT NULL
);

-- V3: Shows customers alongside their rental cost, payment method, and total amount paid - uses join.
CREATE VIEW customer_info(CustomerID, RentalCost, PaymentMethod, TotalAmount) AS (
    SELECT c.CustomerID, rent.RentalCost, p.PaymentMethod, p.TotalAmount
    FROM Customer c, Reservation res, Rental rent, Payment p
    WHERE c.CustomerID = res.CustomerID
    AND res.ReservationID = rent.ReservationID
    AND rent.RentalID = p.RentalID
);

-- V4: Lists all vehicles type luxury with their ID, model, and daily rate
CREATE VIEW luxury_vehicles(VehicleID, Model, DailyRate) AS (
    SELECT VehicleID, Model, DailyRate
    FROM Vehicle
    WHERE VType = 'Luxury'
);

-- V5: --1) Show Vehicles with assocaited repair type, parts repaired and service date
CREATE VIEW vehiclerepairs_andparts AS (
    SELECT vehicle.VehicleID, Model, repairs.RepairType, repairs.ServiceDate, Part
    FROM vehicle, repairs, partsRepaired
    WHERE vehicle.VehicleID = repairs.VehicleID
    AND partsRepaired.VehicleID = repairs.VehicleID
    AND partsRepaired.ServiceDate = repairs.ServiceDate
);

-- V6: Shows all reservations that are still pending by customer, vehicle, and date details 
CREATE VIEW pending_reservations AS (
    SELECT vehicle.VehicleID, Model, customer.CustomerID, FirstName, LastName, Email, reservation.ReservationID, RStatus, PPickupDate, PReturnDate
    FROM vehicle, customer, reservation
    WHERE vehicle.VehicleID = reservation.VehicleID
    AND customer.CustomerID = reservation.CustomerID -- NEED to relate the customers back to the reservations 
    AND RStatus = 'Pending'
);