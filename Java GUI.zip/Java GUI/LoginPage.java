import java.awt.*;
import java.sql.*;
import javax.swing.*;

public class LoginPage extends JFrame {

    // Text fields for user input
    private JTextField userField;
    private JPasswordField passField;

    public LoginPage() {

        // Set window title and size
        setTitle("Oracle DB Login");
        setSize(400, 250);

        // Center window on screen
        setLocationRelativeTo(null);
        // Close program 
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Main panel
        JPanel mainPanel = new JPanel();
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        // Title label
        JLabel title = new JLabel("Login to Oracle DB", SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 20));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Panel for username/password form fields
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

         // Adds spacing around elements
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;

        // Labels for username and password
        JLabel userLabel = new JLabel("Username:");
        JLabel passLabel = new JLabel("Password:");

         // Input fields
        userField = new JTextField(18);
        passField = new JPasswordField(18);

        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(userLabel, gbc);

        gbc.gridx = 1;
        formPanel.add(userField, gbc);


        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(passLabel, gbc);

        gbc.gridx = 1;
        formPanel.add(passField, gbc);

        // Login button
        JButton loginBtn = new JButton("Login");
        loginBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        loginBtn.setPreferredSize(new Dimension(100, 30));

        // When button is clicked, try to connect to DB
        loginBtn.addActionListener(e -> attemptLogin());

        mainPanel.add(title);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        mainPanel.add(formPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        mainPanel.add(loginBtn);

        setContentPane(mainPanel);
    }


    private void attemptLogin() {
        String username = userField.getText().trim();
        String password = new String(passField.getPassword());

        String dbUrl = "jdbc:oracle:thin:" + username + "/" + password +
                "@oracle.scs.ryerson.ca:1521:orcl";

        try {
            Class.forName("oracle.jdbc.OracleDriver");

             // Try connecting using entered username/password
            Connection conn = DriverManager.getConnection(dbUrl);

            // Open the main CarRental UI using the connection
            CarRentalDBGUI gui = new CarRentalDBGUI(conn);
            gui.setVisible(true);
            // Close login window
            this.dispose();

        } 
        catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Login failed:\n" + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new LoginPage().setVisible(true);
    }
}
